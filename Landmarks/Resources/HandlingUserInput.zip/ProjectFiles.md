# Project files: Handling user input

To follow the [Handling user input](https://developer.apple.com/tutorials/swiftui/handling-user-input) tutorial, start with your completed project from the previous tutorial, or open the Xcode project in the **StartingPoint** folder. To explore on your own, open the Xcode project in the **Complete** folder and browse the project's code.

- Note: To preview and interact with views from the canvas in Xcode ensure your Mac is running macOS Sonoma or later.
