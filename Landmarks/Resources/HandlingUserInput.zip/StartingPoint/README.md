# Completed project: Building lists and navigation

Explore the completed project for the [Building lists and navigation](https://developer.apple.com/tutorials/swiftui/building-lists-and-navigation) tutorial.
